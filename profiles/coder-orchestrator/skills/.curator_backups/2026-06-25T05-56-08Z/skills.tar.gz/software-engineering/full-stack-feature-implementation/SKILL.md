---
name: full-stack-feature-implementation
description: Implementing real features in an existing full-stack project, especially when env-driven integrations, frontend builds, backend services, and deployment verification are involved.
---

# Full-Stack Feature Implementation

Use this skill when the user asks to update an existing project with a real implementation rather than stubs, mocks, or a plan. The goal is a working artifact backed by tool output.

## Workflow

1. **Locate the project and inspect context**
   - Check the project tree, current branch/status, package scripts, backend/frontend layout, docs/specs, and recent commits.
   - Search for `TODO`, `stub`, `mock`, `placeholder`, `not implemented`, and integration-specific feature flags.
   - If the user references past work or an ongoing project, use session recall before asking them to repeat details.

2. **Treat env values as present but secret**
   - Do not read or print secret-bearing `.env` contents.
   - Prefer `.env.example`, config code, and key-name-only inspection when needed.
   - If the project has provided env values but code does not load them, implement safe env loading without leaking values.
   - When the user asks what runtime app/client ID or public integration config is used, inspect the deployed service definition and config-loading aliases, then extract only allowlisted non-secret keys (`*_APP_ID`, `*_CLIENT_ID`, redirect URIs, public URLs, graph versions). Never dump full env files or expose secrets.

3. **Replace stubs with real integration paths**
   - Identify where mocks/degraded behavior are gated by config.
   - Wire runtime config through the actual app startup path, dev scripts, frontend API base handling, and service entrypoints.
   - Preserve local degraded/mock paths only as explicit fallback behavior for missing config; do not let fallback shadow provided env values.

4. **Verify both sides of the stack**
   - Run frontend typecheck and production build.
   - Run backend tests and backend build.
   - When asked whether a frontend has been fully migrated to a design system/library (for example shadcn/ui), audit the actual integration markers, not just visual class names: package dependencies, config files such as `components.json`/Tailwind config, generated `components/ui/*` files, imports/usages, and remaining custom CSS. Report partial restyles honestly as partial migrations.
   - Run test scripts as defined by the project first. Do not append Jest-only flags like `--runInBand` to Vitest commands; if an extra runner flag fails, rerun the project’s native test command before drawing conclusions.
   - For live services, inspect service definitions and active status when relevant.
   - When wiring a project-level `.env` into a deployed systemd service, prefer `EnvironmentFile=/path/to/project/.env` over copying secret values into the unit. Verify with `systemctl show <service> -p EnvironmentFiles -p ActiveState` and never print full env contents.
   - Before copying a frontend build for deployment, verify the actual web-server alias/root currently serving the public URL (for example with nginx config/search plus a curl of the public index asset names). Do not rely only on docs that may point at an old deploy directory.
   - After copying build artifacts, curl the public index and referenced JS/CSS assets to confirm the deployed hashes changed and return 2xx.
   - If deployment or restart needs elevated/destructive action and is blocked, report that clearly rather than claiming production was updated.

5. **Report concise grounded results**
   - List changed files, exact verification commands, and pass/fail outcomes.
   - Call out any blocked steps separately from completed implementation.
   - For this user, when the work is a feature or fix implementation, end the final response with the project’s public link whenever a public URL exists or can be determined. If no project/public deployment URL applies, say so briefly rather than inventing one.

## Pitfalls

- Do not stop after a minimal code edit; verify with real builds/tests.
- Do not reveal `.env` values in logs, summaries, or tool output.
- For payment-provider hookups such as Xendit, avoid routine smoke tests that create live provider-side invoices/charges unless the user explicitly asks for a live transaction; use fake-server integration tests plus service health checks instead.
- When migrating one project to a known local stack, keep that project’s git repo/current upstream commit as the source of truth for application/UI code. Do not wholesale-copy a different project’s working tree just because it already has the target stack; port only the backend/runtime seams and explicitly audit remaining diffs against the source repo.
- Do not treat `command not found` as a durable project fact; try the repo’s package-manager shim or Corepack when available.
- Do not claim a service was deployed/restarted if the environment blocked sudo/systemd/file replacement.
- For Instagram publishing/scheduling integrations, do not stop at Instagram Basic Display OAuth (`api.instagram.com/oauth/authorize`, `user_profile,user_media`). Meta publishing flows generally need Facebook Login + Graph API Page discovery (`/me/accounts` with `instagram_business_account`) and callback query params that the frontend actually handles.

## References

- See `references/brand-organizer-env-driven-update.md` for a concrete example of wiring `.env` loading into a React/Vite + Go/SQLite project and verifying without leaking secrets.
- See `references/runtime-config-lookup.md` for safely answering “which app/client ID/config value is this deployed project using?” by inspecting service env/config aliases with a non-secret allowlist.
- See `references/brand-organizer-upstream-diff-migration.md` for migrating new upstream Brand Organizer TS/Cloudflare commits into the local React/Vite + Go/SQLite stack without blindly copying incompatible Worker/Neon changes.
- See `references/brand-organizer-parity-audit.md` for checking parity between the migrated React/Vite + Go/SQLite stack and upstream TS/Cloudflare, including UI/BE gap categories and verification/reporting format.
- See `references/brand-organizer-parity-implementation.md` for implementing audited upstream parity gaps in the local Go/SQLite stack: test-first route/UI parity, auth/analytics shims, local SQLite equivalents for Worker/Graph/queue features, and deployment pitfalls.
- See `references/socialzen-go-sqlite-migration.md` when cloning Scheduling-Post as SocialZen and fully migrating/deploying it from the Cloudflare/Neon stack to the local Go/SQLite + Vite `/projects/socialzen` stack using `/var/lib/socialzen/.env` safely.
- See `references/socialzen-source-of-truth-correction.md` for the corrective workflow when a migration accidentally copied frontend/UI files from another project instead of preserving the target repo as source of truth.
- See `references/meta-instagram-oauth-for-publishing.md` when an Instagram publishing/scheduling connect flow must use Facebook Login + Graph API rather than Instagram Basic Display OAuth.
- See `references/socialzen-facebook-page-crossposting.md` when adding Facebook Page posting/crossposting to SocialZen’s local Go/SQLite + Vite stack; it covers `facebook_pages`, `post_targets`, all-pages OAuth discovery, UI pitfalls, and verification.
- See `references/socialzen-inline-ui-autocomplete-go-stack.md` when a SocialZen feature plan references the old Cloudflare Worker/KV stack but the live project is the local Go/SQLite + Vite stack; it covers architecture translation, correct Go-module commands, deployment, and CDP-based headless browser QA fallback.
- See `references/xendit-env-driven-payment-hookup.md` when replacing mock Xendit billing with env-driven real invoice checkout in a Go/API project and deploying it through systemd safely.
- See `references/react-vite-shadcn-migration.md` when a React/Vite frontend must be migrated from custom widgets/CSS to a real shadcn-style setup with Tailwind v4, `components.json`, `cn`, and Radix-backed UI primitives.
