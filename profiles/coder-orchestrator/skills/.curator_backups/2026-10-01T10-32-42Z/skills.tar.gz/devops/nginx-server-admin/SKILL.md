---
name: nginx-server-admin
description: Administer the nginx web server on the user's Oracle Cloud instance — SSL/HTTPS setup, port and firewall management (two-layer ufw + OCI Security List), project routing config, and deployment verification. Use when the user asks to enable HTTPS, open ports, configure SSL certs, add or modify nginx routes, or troubleshoot public access issues.
---

# Nginx Server Admin

Administer nginx and network access on the user's Oracle Cloud instance (IP `168.110.213.104`).

## Server Layout

- **nginx config**: `/etc/nginx/nginx.conf` includes `/etc/nginx/projects/*.conf`
- **Active project config**: `/etc/nginx/projects/default.conf` — single `server` block with path-based routing under `/projects/<slug>/`
- **Static project files**: `/var/www/html/projects/<slug>/`
- **PRD/review HTML files**: `/usr/share/nginx/html/prds/` (served at `/prd/<name>`)
- **Project API backends**: each project's Go/Node API runs on a localhost port (e.g. socialzen=8089, komuna=8095, self-flow=8096), proxied via `location ^~ /projects/<slug>/api/`
- **SSL certs**: `/etc/nginx/ssl/selfsigned.crt` + `.key` (self-signed, 365-day expiry)

## Oracle Cloud Two-Layer Firewall (critical)

This server has **two independent firewalls**. Both must allow a port for public access:

1. **OS-level (ufw)** — `sudo ufw allow <port>/tcp`. You manage this from the terminal.
2. **Network-level (OCI Security List)** — configured in the Oracle Cloud Console, NOT from the server. See `references/oracle-cloud-security-list.md` for exact steps.

**Diagnostic pattern**: If `curl http://localhost:<port>/` works but `curl http://168.110.213.104:<port>/` times out (not "connection refused", but hangs), the OCI Security List is blocking the port. ufw is open but the network firewall is not.

Port 80 was pre-opened in both layers. New ports (e.g. 443) need both.

## Enabling HTTPS

### Self-Signed Cert (bare IP, no domain)

Use when the user has no domain name and accepts browser warnings.

```bash
# 1. Generate cert (include IP as SAN)
sudo mkdir -p /etc/nginx/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/nginx/ssl/selfsigned.key \
  -out /etc/nginx/ssl/selfsigned.crt \
  -subj "/CN=168.110.213.104" \
  -addext "subjectAltName=IP:168.110.213.104"

# 2. Add listen 443 ssl to the server block in /etc/nginx/projects/default.conf
#    Add these lines after the existing listen 80 directives:
#    listen 443 ssl;
#    listen [::]:443 ssl;
#    ssl_certificate /etc/nginx/ssl/selfsigned.crt;
#    ssl_certificate_key /etc/nginx/ssl/selfsigned.key;
# Use sudo perl -0777 -i -pe for multiline edits (patch tool refuses system paths)

# 3. Open ufw
sudo ufw allow 443/tcp

# 4. Test and reload
sudo nginx -t && sudo systemctl reload nginx

# 5. Verify locally (bypasses OCI firewall)
curl -k https://localhost/health
curl -k -o /dev/null -w "%{http_code}" https://localhost/projects/socialzen/
```

After server-side setup, the user must open port 443 in the OCI Security List (see `references/oracle-cloud-security-list.md`).

### Let's Encrypt (requires a domain)

Use when the user has a domain pointed at `168.110.213.104`. Free, auto-renewing, no browser warnings.

**Prerequisites** (all three must be true before running certbot):
1. DNS A record for the domain resolves to `168.110.213.104` — verify: `python3 -c "import socket; print(socket.gethostbyname('<domain>'))"`
2. OCI Security List has port 443 open (see `references/oracle-cloud-security-list.md`)
3. nginx server block for the domain exists and is loaded (certbot will modify it)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d <domain>
# Certbot auto-edits the nginx server block: adds listen 443 ssl, cert paths, and HTTP→HTTPS redirect
# Renewal timer is set up automatically via systemd
```

Let's Encrypt cannot issue certs for bare IP addresses — a domain is required.

## Domain Integration for Path-Based Projects (Single Build, Clean Root URL)

When a user asks to **move access / expose an existing FE build at a domain** and does not ask for code changes, first check whether the already-deployed path build is good enough. The shortest safe fix is often nginx-only: add a domain server block rooted at `/var/www/html/projects/<slug>`, use reverse `sub_filter` to strip `/projects/<slug>/` from HTML/JS asset/API references, proxy both `/api/` and `/projects/<slug>/api/`, then verify with `curl --resolve` and public Cloudflare/DNS. Rebuild only when the JS bundle cannot be safely rewritten or runtime config is required.

When a user wants a custom domain for a path-based Vite/React project, use a **single build** with `VITE_BASE=/` plus nginx `sub_filter` on the path-based deployment. The domain gets clean root URLs, the IP path continues to work — **one canonical build directory** (`/var/www/html/projects/<slug>/`).

```
https://<domain>/          → root /var/www/html/projects/<slug>/   (native, no sub_filter)
http://<ip>/projects/<slug>/ → alias + sub_filter rewrites assets  (injects runtime overrides)
```

This avoids maintaining two separate build directories and two separate Vite builds. Clean domain URLs without redirect.

### Code Prerequisites (one-time per project)

The frontend must support runtime overrides for React Router `basename` and API base URL. See `references/single-build-subfilter.md` for the exact code patches.

### Setting Up the Domain Config

```nginx
# /etc/nginx/projects/<slug>-domain.conf
server {
    listen 80;
    listen [::]:80;
    server_name <domain>;

    root /var/www/html/projects/<slug>;          # ← canonical build dir
    index index.html;

    # API/webhook proxied at root level AND path-prefixed (DB may store both)
    location ^~ /api/ { proxy_pass http://127.0.0.1:<port>/api/; ... }
    location ^~ /projects/<slug>/api/ { proxy_pass http://127.0.0.1:<port>/api/; ... }

    location / {
        try_files $uri $uri/ /index.html;
    }

    listen 443 ssl; ... # certbot
}
```

### Setting Up the Path-Based Config (sub_filter)

The path-based deployment in `/etc/nginx/projects/default.conf` must rewrite asset paths and inject runtime overrides:

```nginx
location /projects/<slug>/ {
    alias /var/www/html/projects/<slug>/;
    index index.html;
    try_files $uri $uri/ /projects/<slug>/index.html;
    sub_filter_types text/html;
    sub_filter 'src="/assets/' 'src="/projects/<slug>/assets/';
    sub_filter 'href="/assets/' 'href="/projects/<slug>/assets/';
    sub_filter '</head>' '<script>window.__BASENAME__="/projects/<slug>";window.__API_BASE__="/projects/<slug>/api/v1"</script></head>';
    sub_filter_once off;
}
```

`sub_filter` requires `ngx_http_sub_module` — included by default in Ubuntu's nginx. Verify: `sudo nginx -V 2>&1 | grep sub_module`.

### Deploy

```bash
# Build with root base
cd <project>/apps/web
rm -rf dist
VITE_BASE=/ VITE_API_BASE_URL=/api/v1 npm run build   # (or pnpm build for pnpm projects)

# Deploy to canonical directory (updates BOTH domain and IP path)
sudo rsync -a --delete dist/ /var/www/html/projects/<slug>/

# Reload
sudo nginx -t && sudo systemctl reload nginx
```

### Verify

```bash
# Domain: clean root URL, no redirect, assets at /assets/...
curl -k https://<domain>/
curl -k https://<domain>/some-deep-route   # SPA fallback works

# IP path: assets rewritten to /projects/<slug>/assets/..., overrides injected
curl http://168.110.213.104/projects/<slug>/

# Both should return 200 with correct asset hashes
```

### Cleanup Old Duplicate Directory

```bash
sudo rm -rf /var/www/html/<slug>   # if an old domain-specific build dir exists
```

⚠️ **Pitfalls for this approach:**
- The frontend MUST support `window.__BASENAME__` and `window.__API_BASE__` runtime overrides. Without these code changes, the path-based deployment will have broken routing and API calls. See `references/single-build-subfilter.md`.
- `sub_filter_once off` is critical — without it, only the first match in the HTML is rewritten, leaving other asset references broken.
- The API base value injected via `__API_BASE__` must match what the path-based nginx config proxies. For komuna: `/projects/komuna/api/v1`. For socialzen: `/projects/socialzen` (its code appends `/api` separately).
- The `location ^~ /api/` block on the domain server block is for the domain deployment (root build calls `/api/...`). The path-based deployment injects `__API_BASE__` so it calls the correct path-prefixed URL.
- `sub_filter_types text/html` may produce a harmless warning about duplicate MIME types if multiple projects use it — this is safe to ignore.
- Never redirect the domain root to `/projects/<slug>/`. The user wants clean URLs.

## Renaming a Path-Mounted Static Project

Treat a rename as an identity and routing cutover, not merely a directory move:

1. Begin from a clean Git state and inventory the old slug in source metadata, visible branding, browser-storage namespaces, build/test scripts, deployment paths, and nginx.
2. Rename source/package/product identity first. If the repository directory moves, immediately switch every later tool call to the new working directory.
3. Build with the new Vite base and assert generated HTML contains the new prefix and no old slug before deployment.
4. Deploy with `rsync --delete` only to the new project leaf; never target the shared `/projects/` parent.
5. Replace nginx's exact-slash redirect, alias, and SPA fallback together. Preserve literal `$uri` with a quoted script or payload, then read the resulting block back before `nginx -t`.
6. Make the old URL policy explicit. For a true replacement, add exact and prefix `404` rules for the old slug; redirect only when backward compatibility is requested.
7. Verify separately: new HTML, referenced JS/CSS MIME types, deep-link fallback, browser-visible title/brand, client routing under the new basename, and terminal behavior of both old root and old deep paths.
8. Remove the old deployment leaf only after the new public route passes. Commit source changes separately from runtime nginx state and report honestly when no Git remote exists.

Use a unique cache-busting query for public HTML and search both source and generated output for the old slug; a successful new root request alone does not prove the identity cutover is complete.

## Adding a New Project Route

To serve a new project under `/projects/<slug>/`:

0. Diagnose the frontend and backend independently. Existing API/health proxy blocks and a healthy backend do **not** mean the SPA is deployed. Check all three:
   - `/var/www/html/projects/<slug>/index.html` exists
   - nginx has an exact slash redirect plus a frontend `location /projects/<slug>/` block
   - the API/health proxy reaches its localhost service

1. Build the frontend, copy to `/var/www/html/projects/<slug>/`
2. Add a `location` block to `/etc/nginx/projects/default.conf`:
   ```nginx
   location = /projects/<slug> { return 301 /projects/<slug>/; }
   location /projects/<slug>/ {
       alias /var/www/html/projects/<slug>/;
       index index.html;
       try_files $uri $uri/ /projects/<slug>/index.html;
   }
   ```
3. If the project has an API, add a proxy block:
   ```nginx
   location ^~ /projects/<slug>/api/ {
       proxy_pass http://127.0.0.1:<port>/api/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   ```
4. `sudo nginx -t && sudo systemctl reload nginx`
5. Verify the public path—not just localhost—and verify the referenced assets have the right MIME type:
   ```bash
   curl -fsS http://<public-ip>/projects/<slug>/
   curl -fsSI http://<public-ip>/projects/<slug>/assets/<main-bundle>.js
   ```
   Expect app HTML and `Content-Type: application/javascript`; a `200 text/html` asset response is an SPA fallback, not success.

### Dual domain + bare-IP diagnostics

- Test DNS first (`getent ahostsv4 <domain>` or `dig +short <domain>`). If empty, the domain cannot work publicly even when origin nginx is correct.
- Test the not-yet-live domain against the origin with `curl --resolve <domain>:80:<public-ip> http://<domain>/`. This proves only origin routing; report DNS as unresolved until normal public resolution succeeds.
- When several port-80 virtual hosts exist, make the catch-all/path server explicit with `listen 80 default_server;` and `listen [::]:80 default_server;`. Otherwise a bare-IP request may land in whichever domain server nginx loads first, and `sub_filter` can silently rewrite the wrong response.
- After changing virtual-host order/defaults, re-run the bare-IP HTML and asset checks. Do not infer correctness from an origin `Host:` test alone.

## Editing System nginx Configs

The `patch` tool refuses to write to `/etc/nginx/`. Use terminal with `sudo`:
- Single-line edits: `sudo sed -i 's/old/new/' /etc/nginx/projects/default.conf`
- Multiline edits: `sudo perl -0777 -i -pe 's/old/new/' /etc/nginx/projects/default.conf`
- Always back up first: `sudo cp /etc/nginx/projects/default.conf /etc/nginx/projects/default.conf.bak.$(date +%Y%m%d%H%M%S)`

## Pitfalls

- **Subpath SPA API calls must use the deployed base path**: A Vite app mounted at `/projects/<slug>/` must not hard-code root `/api/...` unless that root proxy is deliberately owned by the same app. Prefer deriving the client API prefix from `import.meta.env.BASE_URL` (for example, `${BASE_URL}api`) and verify built browser requests hit `/projects/<slug>/api/...`. Unit tests should preserve the production prefix rather than hiding it with root-only mocks.
- **Port selection and service cutover need read-back plus ownership verification**: Before assigning a localhost port, inspect the actual listener owner (`ss -ltnp`), not just whether a probe responds. After editing systemd/nginx, read back both effective endpoints before restarting, then require `systemctl is-active`, a direct application-specific health fingerprint, and the proxied fingerprint. A generic JSON health response can belong to the wrong healthy service. If a chained shell command exits before its replacement step, do not assume configuration changed—read it back.
- **Shell expansion can silently corrupt generated nginx blocks**: Do not put nginx variables such as `$uri` inside a double-quoted shell command or unquoted heredoc; the shell may expand them before writing the config, producing rules like `try_files / /projects/app/index.html` and redirect loops. Prefer a single-quoted Python/Perl payload, a quoted heredoc, or escape every `$`. Immediately read back the inserted block before `nginx -t` and verify it still contains literal `$uri`.
- **Reload may leave old workers serving a repaired route inconsistently**: After fixing an internal-redirection loop, test with the intended `Host` header as well as `localhost`. If `nginx -t` and reload succeed but localhost and public-host results disagree or logs still name the old rule, perform a bounded `systemctl restart nginx`, then re-probe localhost, origin IP, origin with `--resolve`, and the public URL. Treat this as a reload boundary, not an application defect.
- **Dist not auto-deployed to nginx**: After `npm run build` / `npx vite build` completes, the build output sits in the project's local `dist/` directory. A git push alone does not update nginx-served sites. You MUST manually copy it to the served directory, preferably with deletion so removed hashed assets do not linger: `sudo rsync -a --delete dist/ /var/www/html/projects/<slug>/`. If the user says they "don't see" a change you know you made, first compare the live index asset hash with the built one: `curl -fsSL https://<domain>/ | grep -o 'assets/index-[^\"]*\\.js' | head -1` and `grep -o 'assets/index-[^\"]*\\.js' dist/index.html | head -1`.
- **Domain deploys use the same directory now**: Domains are served from `/var/www/html/projects/<slug>/` via the single-build + sub_filter pattern. Deploying to that one directory updates BOTH the IP path and the domain. If a domain existed before this change, it may have had a stale `/var/www/html/<slug>/` copy — remove it. The #1 stale-domain suspect is an out-of-date `/var/www/html/projects/<slug>/` — check the asset hash or `md5sum` against the source `dist/index.html`.
- **Cloudflare caches old hashed asset paths**: If the domain HTML updates but the referenced Vite hash is already cached as the old bundle, or the newly referenced asset URL returns HTML due to a stale fallback cache, purge Cloudflare when credentials exist. Without a token, use a one-off cache-bust: copy the built main bundle to a fresh name (for example `assets/index-<commit>.js`) and replace that filename in the deployed `index.html`, then verify `curl -sI https://<domain>/assets/index-<commit>.js` returns `Content-Type: application/javascript` and the live index references the new name. This is a hotfix for proxied nginx sites with `max-age=14400`, not a source-code change.
- **Single canonical build directory**: All deploys go to `/var/www/html/projects/<slug>/` — this is the ONLY build directory for the project. Both the domain and the IP path serve from here. If you find a `/var/www/html/<slug>/` directory (without `projects/`), it is a stale duplicate from an old dual-build setup — remove it after confirming the new single-build config is active.
- **Forgetting the OCI Security List**: Opening ufw alone is not enough. If public access times out but localhost works, the Security List is the blocker — you cannot fix it from the terminal.
- **Self-signed cert browser warnings**: Browsers show "Not Secure" / "Your connection is not private". Users must click Advanced then Proceed. This is expected, not a bug. Mention the upgrade path to Let's Encrypt if they get a domain.
- **Cert expiry**: Self-signed certs expire. Regenerate with the same openssl command or set up a calendar reminder. Let's Encrypt auto-renews via systemd timer.
- **nginx config syntax**: Always run `sudo nginx -t` before reload. A syntax error in the config will prevent nginx from starting on reload.
- **Vite base path mismatch**: If a Vite SPA built with `base: "/projects/foo/"` is served at a different path (e.g. domain root `/`), all asset requests 404 because the built HTML references `/projects/foo/assets/...`. You must rebuild with the correct `base` for each deployment path. See "Domain Integration for Path-Based Projects" above.
- **Domain config missing path-prefixed media/api blocks**: When a project migrates from path-based (`/projects/<slug>/`) to a custom domain, the domain nginx config typically adds `location ^~ /api/` and `location ^~ /media/`. But URLs stored in the database (e.g. media paths from `SaveUpload`) still use the FULL prefix `/projects/<slug>/media/user_.../upload_...jpg`. If the domain config does NOT also proxy `location ^~ /projects/<slug>/media/` and `location ^~ /projects/<slug>/api/`, those URLs fall through to the SPA catch-all (`location /`) and return HTML instead of the actual image. External platforms (Instagram/Facebook Graph API) silently receive HTML, causing publish failures with no visible error. Always add BOTH the root-level and path-prefixed location blocks to the domain config. Verify with `curl -sI https://<domain>/projects/<slug>/media/<test-file>` returning `Content-Type: image/jpeg` — not `text/html`. **Follow-on**: even after fixing the nginx config, Cloudflare may have cached the old HTML fallback (200 OK with wrong content-type) for hours. See `references/cloudflare-stale-cache-nginx-routing.md` for diagnosis and cache-busting fix.
- **Vite env var precedence**: Process env vars (e.g. `VITE_API_URL=/ vite build`) override `.env.production` values. Use this to build the same source for different deployment targets without modifying env files.
- **Missing `.env` file causes blank page on rebuild**: If a project's `.env.example` contains `VITE_BASE_PATH=/projects/<slug>/` but no corresponding `.env` file exists, the Vite build silently defaults to `base: "/"`. All asset references in `index.html` become root-relative (`/assets/...`) instead of path-prefixed (`/projects/<slug>/assets/...`). The page renders blank with no visible errors — the HTML loads but every JS/CSS request 404s. **Fix**: verify `ls packages/*/.*env packages/*/.env` after a rebuild produces a blank page — the `.env` file is the #1 suspect. Create it at `packages/<fe>/env` with `VITE_BASE_PATH=/projects/<slug>/` matching the `.env.example` value.
- **Backend redirect URLs for dual deployment**: When the backend constructs redirect URLs (OAuth callbacks, payment returns), it must use the correct base for each deployment. A common bug: the backend's `frontendURL()` helper appends a hardcoded project prefix even when the domain SPA is served at root. See `references/vite-domain-deployment.md` Pitfalls 1–3 for the full pattern.
- **Cloudflare proxied DNS + certbot redirect loop**: If `curl -L https://<domain>/` stays at `301 Location: https://<same-domain>/`, Cloudflare may be hitting origin HTTP while certbot's HTTP block redirects to HTTPS. Serve the app on both HTTP and HTTPS in the main domain server block and remove the redirect-only HTTP block; see `references/vite-domain-deployment.md` HTTPS section.
- **Relative slash redirects can downgrade public HTTPS behind Cloudflare**: An exact nginx rule such as `location = /projects/<slug> { return 301 /projects/<slug>/; }` may emit an absolute `Location: http://<domain>/...` when Cloudflare connects to the origin over HTTP, even though the visitor requested HTTPS. For a canonical public HTTPS hostname, return the explicit external URL instead: `return 301 https://<domain>/projects/<slug>/;`. Verify both forms publicly with `curl -sSIk https://<domain>/projects/<slug>` and require an HTTPS `Location`, then verify the trailing-slash destination returns the app.
- **Nested Cloudflare hostname may lack edge TLS coverage**: A hostname such as `dev.app.example.com` can resolve through proxied Cloudflare DNS and reach the origin over HTTP while public HTTPS fails before returning any HTTP response (`sslv3 alert handshake failure`, no peer certificate). A successful origin certificate issuance does not fix Cloudflare edge TLS. Diagnose the two layers separately: verify origin HTTPS with `curl --resolve <host>:443:127.0.0.1 https://<host>/`, inspect the origin certificate with `openssl s_client -connect 127.0.0.1:443 -servername <host>`, then test public HTTPS normally. If origin HTTPS works but the Cloudflare address presents no certificate, enable or issue Cloudflare edge certificate coverage for that exact nested hostname (Universal SSL commonly covers only the apex and one-label subdomains; deeper names may require Advanced Certificate Manager or a custom certificate). Do not call the migration done until the public URL itself succeeds. See `references/cloudflare-nested-hostname-tls.md`.
- **Domain config blank page (incomplete reverse `sub_filter`)**: If a build uses a non-root base, strip the legacy prefix from both HTML and JavaScript. Healthy HTML/assets alone do not prove the app works: the compiled bundle may still call a disabled path-prefixed API. Minified Vite strings can use double quotes, single quotes, or template-literal backticks, so cover all three:
  ```nginx
  sub_filter_types text/html application/javascript text/javascript;
  sub_filter '"/projects/<slug>/' '"/';
  sub_filter "'/projects/<slug>/" "'/";
  sub_filter '`/projects/<slug>/' '`/';
  sub_filter 'basename:"/projects/<slug>/"' 'basename:"/"';
  sub_filter_once off;
  ```
  Inspect the served bundle and require zero legacy-prefix occurrences. Verify the root API returns an expected application response (for example `401`, not SPA HTML), and JS is `application/javascript`. Prefer rebuilding with `VITE_BASE=/` when practical.
- **Domain-only cutover order**: Make the domain root, JS, and root API work first. Then deny every legacy path—including old API/health locations—with one exact and one prefix rule:
  ```nginx
  location = /projects/<slug> { return 404; }
  location ^~ /projects/<slug>/ { return 404; }
  ```
  Keep the canonical build directory when it remains the domain document root. Verify the public domain, public API, legacy root `404`, and legacy API `404`.
- **HTTPS is a separate vhost check**: A working port-80 domain block does not make HTTPS serve that app. Inspect origin SNI with `curl -v --resolve <domain>:443:127.0.0.1 https://<domain>/`; confirm the certificate CN/SAN and selected 443 server belong to the requested hostname. Configure/issue its certificate when absent, then verify the public URL—not only an origin `Host:` test.
- **Cloudflare DNS diagnosis**: If the host resolver is stale or empty, query Cloudflare or Google DNS-over-HTTPS JSON to distinguish propagation from origin failure. Proxied A answers are Cloudflare edge IPs, not the origin; test those with `curl --resolve` while preserving hostname/SNI. Add a cache-busting query when checking transformed JS through Cloudflare.

## Shared Static-Root Blast Radius

When unrelated SPA domains begin returning nginx `500` sequentially and logs show an internal redirect cycle to a missing `index.html`, do not restore only the reported app. Inventory every nginx `root`/`alias` under the shared static tree and inspect recent privileged deployment history for `rsync --delete` aimed at `/var/www/html/` or `/var/www/html/projects/`. One overly broad deploy can delete sibling projects while their API services remain healthy.

Restore all missing leaf deployments, narrow any domain vhost rooted at the shared ancestor to its project leaf, and publicly verify HTML plus a referenced JS/CSS asset for every configured app. See `references/shared-static-root-deployment-blast-radius.md` for the diagnosis, recovery, prevention, and fleet-wide verification recipe.

## References

- See `references/exact-provider-callback-routing.md` for narrowly scoped callback proxies, HTTP/HTTPS parity, SNI/certificate verification, exact challenge-response probes, and query-string secret hygiene.
- See `references/wrong-healthy-upstream.md` when a public route reaches a healthy listener belonging to the wrong application; it covers exact-route capture, port/process ownership, service-specific response fingerprints, minimal proxy correction, and authenticated public verification without manufacturing a source commit.
- See `references/fleet-wide-git-realignment-and-deployment.md` for the end-to-end orchestrator pattern: nginx-driven discovery, bounded parallel batches, conservative branch/worktree pruning, distrust-and-verify handling of worker summaries, final fleet probes, and status reporting.
- See `references/canonical-main-realignment-and-deployment.md` when completed work is stranded on stacked task branches while a stale `main` also backs a live systemd/nginx deployment; it covers dirty-work preservation, non-rewriting integration, runtime backup, exact-target deployment, remote validation, and conservative ref cleanup.
- See `references/nginx-application-inventory-and-realignment.md` for fleet-wide “every remaining app” work: exhaustive `nginx -T` classification, monorepo identity checks, API-only route handling, canonical-branch rules, exact-target deployment, and a no-route-skipped report.
- See `references/static-spa-canonical-rename.md` for the full source/package/nginx/deployment/public-E2E checklist when both a project name and `/projects/<slug>/` URL change.
- See `references/prefix-mounted-single-binary-deployment.md` when one binary embeds the SPA and natively mounts UI + API at the same public prefix; it covers no-strip proxying, Cloudflare redirect-cache diagnosis, scoped-cookie verification, CSRF rotation, and safe SMTP capture for public E2E.
- See `references/oracle-cloud-security-list.md` for step-by-step instructions to open a port in the OCI Security List (the network-level firewall that cannot be configured from the server).
- See `references/single-build-subfilter.md` for the full code patches, nginx sub_filter config, and verification steps for the single-build domain + path deployment pattern (the current preferred approach).
- See `references/vite-domain-deployment.md` for the legacy dual-build pattern (historical reference only — do NOT use for new setups).
- See `references/reverse-subfilter-domain-no-rebuild.md` for the full domain config template when adding a domain to an existing path-based build without rebuilding (the exact config used for self-flow → selfflow.ahsanworks.com).
