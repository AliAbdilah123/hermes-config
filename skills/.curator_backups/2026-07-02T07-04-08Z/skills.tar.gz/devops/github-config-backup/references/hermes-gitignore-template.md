# Validated .gitignore for `~/.hermes`

Use this as a starting point for `~/.hermes/.gitignore`. It was built from a live
survey of `/home/ubuntu/.hermes` and excludes:
- secrets (`.env`, `auth.json`, `*.lock`, `*.key`, `*.token`, `*.secret`, `*.pem`)
- databases and WAL/SHM files
- runtime state (`gateway_state.json`, `processes.json`, `discord_threads.json`, etc.)
- logs (all `**/*.log` and `logs/` dirs)
- sessions (private conversation history)
- caches (`cache/`, `audio_cache/`, `image_cache/`, `context_length_cache.yaml`, provider/model caches)
- downloaded/vendored artefacts (`node/`, `bin/`, `node_modules/`, `venv/`, lockfiles)
- large runtime directories (`home/`, `sandboxes/`, `pairing/`)
- profile-specific runtime copies and lockfiles
- nested agent source tree (`hermes-agent/`)
- OS/editor junk

```gitignore
# ──────────────────────────────────────────────────────────────
# ~/.hermes  –  Sensitive data, runtime artefacts, caches
# ──────────────────────────────────────────────────────────────

# ── Secrets / tokens / auth ──
.env
auth.json
auth.lock
shared/nous_auth.json
shared/nous_auth.lock
*.secret
*.token
*.key
*.pem

# ── Databases / state ──
*.db
*.db-wal
*.db-shm
state.db*
kanban.db*

# ── Locks ──
*.lock

# ── Runtime JSON state (non-config) ──
gateway_state.json
gateway.lock
processes.json
discord_threads.json
channel_directory.json
*.prompt_snapshot.json
.skills_prompt_snapshot.json

# ── Hermes-specific runtime artefacts ──
.hermes_history
gateway.pid
.update_check
interrupt_debug.log

# ── Logs ──
**/*.log
**/*.diag.log
logs/
**/logs/

# ── Sessions (private conversation history) ──
sessions/
**/sessions/

# ── Caches ──
cache/
audio_cache/
image_cache/
*.cache
context_length_cache.yaml
provider_models_cache.json
models_dev_cache.json
ollama_cloud_models_cache.json
*.recommended_cache.json
*.openrouter_model_metadata.json

# ── Downloaded / compiled / vendored artefacts ──
bin/
node/
lsp/node_modules/
**/node_modules/
**/venv/
package-lock.json
uv.lock
flake.lock
*.lock

# ── Large runtime directories not needed for backup ──
home/
sandboxes/
pairing/
profiles/*/home/
profiles/*/sandboxes/
profiles/*/pairing/
profiles/*/cache/
profiles/*/lsp/node_modules/
profiles/*/bin/
profiles/*/state.db*
profiles/*/gateway.lock
profiles/*/.env
profiles/*/auth.json
profiles/*/auth.lock
profiles/*/cron/.tick.lock
profiles/*/cron/.jobs.lock
profiles/*/gateway_state.json
profiles/*/discord_threads.json
profiles/*/processes.json
profiles/*/models_dev_cache.json
profiles/*/channel_directory.json
profiles/*/.skills_prompt_snapshot.json

# ── Agent source tree (tracked in its own repo inside hermes-agent) ──
hermes-agent/

# ── Cron runtime files ──
cron/.tick.lock
cron/.jobs.lock
cron/output/

# ── Plan-specific artifacts ──
*.bak.*

# ── OS / editor junk ──
.DS_Store
Thumbs.db
*.swp
*.swo
*~
.~*
```

## Validation checklist
After writing this file:
1. `git status --short` inside the target dir
2. Confirm no `*.env`, `auth.json`, `*.lock`, `*.db`, `*.log`, `sessions/`, or `cache/` entries are staged
3. Confirm `profiles/*/home/…` vendored paths (e.g. Go module cache) are absent from the index
