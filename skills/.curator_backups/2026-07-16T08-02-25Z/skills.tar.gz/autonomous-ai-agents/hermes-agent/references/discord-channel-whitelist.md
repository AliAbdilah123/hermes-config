# Discord Channel Whitelisting for Multi-Profile Setups

In multi-profile Hermes deployments, each profile runs its own gateway and maintains an independent Discord channel whitelist. Adding a channel to one profile’s whitelist does **not** make it available to other profiles.

## Where the config lives

| Location | When to edit |
|----------|--------------|
| `$HERMES_HOME/config.yaml` — `discord.allowed_channels` | Main / default profile |
| `$HERMES_HOME/profiles/<profile>/config.yaml` — `discord.allowed_channels` | Named profile gateways |
| `~/hermes-config/profiles/<profile>/config.yaml` — `discord.allowed_channels` | Source of truth when ops-root sync is in use |

`$HERMES_HOME` is profile-specific. The running gateway process sets it via `HERMES_HOME=<runtime>/profiles/<profile>`.

## Source config vs runtime config

In environments with an ops root (e.g. `/home/ubuntu/hermes-config/profiles/<profile>/config.yaml`), changes must be kept in sync:

1. The **source/config-of-truth** copy lives under the ops root.
2. The **runtime** copy consumed by the gateway is `$HERMES_HOME/profiles/<profile>/config.yaml`.
3. After editing the source file, propagate it to the runtime location before restarting the gateway.

If these drift, a gateway restart will revert config changes or silently load stale values.

## Config shape

Use a YAML list of channel IDs (strings), not a quoted scalar:

```yaml
discord:
  require_mention: false
  free_response_channels: ''
  allowed_channels:
    - '1510322701141803199'
    - '1518954680510578830'
    - '1518954766594736282'
  auto_thread: true
  thread_require_mention: false
  history_backfill: true
  reactions: true
  channel_prompts: {}
```

**Pitfall:** the Discord adapter converts `allowed_channels` to the `DISCORD_ALLOWED_CHANNELS` env var by joining values with commas. A scalar string like `'1510322701141803199,1518954680510578830'` is also accepted, but the list form above is easier to maintain and avoids quoting mistakes.

## Setting default conversation context per channel with `channel_prompts`

To make a channel or thread implicitly default to a specific project/topic, set `channel_prompts`:

```yaml
discord:
  channel_prompts:
    '1522548954896662568': "Default Project: siapjasa-simple. Treat conversation context here as work on the siapjasa-simple project."
```

Keys may be channel IDs or `channel:thread` pairs. This prompt is injected into the system prompt for that channel, so future sessions in that channel pick up the context without restating it each turn.

## Discovery: where to get channel IDs

`$HERMES_HOME/channel_directory.json` is rebuilt on gateway startup and refreshed every 5 minutes. Each entry contains:

```json
{
  "id": "1518954680510578830",
  "name": "p-socialzen",
  "guild": "Ali's workflow",
  "type": "channel"
}
```

For threads, the relevant IDs are:
- `parent_chat_id` — the text channel hosting the thread
- `thread_id` — the thread itself; also appears as `parent_id + ":" + thread_id` in session keys

Whitelist both the parent channel and the thread when you want the bot to respond inside the thread.

## Restart

Config changes are only loaded on gateway start. For named profiles:

```bash
# Graceful restart (may hang if SIGTERM is blocked)
systemctl --user restart hermes-gateway-<profile>.service

# If restart stalls, force-kill the old PID, reload units, then start
kill -9 <old-pid>
systemctl --user daemon-reload
systemctl --user start hermes-gateway-<profile>.service
```

**Pitfall:** running `hermes gateway restart` from *inside* the gateway process is blocked to prevent restart loops. Use `systemctl --user` from a background shell instead.

**Pitfall:** `systemctl --user restart` can hang because `systemd --user` sends SIGTERM gracefully and the Python asyncio loop may delay shutdown for active tasks. If the unit stays in `deactivating (stop-sigterm)` for more than ~90s, `systemctl --user status` will show `SubState=stop-sigterm` and `MainPID=<n>`. Kill the old PID and `systemctl --user start` the unit.

## Verifying

1. `systemctl --user status hermes-gateway-<profile>.service` — unit is `active (running)`.
2. Inspect logs:
   ```bash
   tail -n 20 /home/ubuntu/.hermes/profiles/<profile>/logs/gateway.log
   # or if HERMES_HOME for that profile is elsewhere:
   tail -n 20 ~/.hermes/logs/gateway.log
   ```
3. Send a message in the target channel. If the bot responds, the whitelist is active.

## Guarding: restrict one profile, leave another alone

In a multi-bot server:
- Profile A (e.g. main) ignores the orchestrator channel by setting `discord.ignored_channels` (or `free_response_channels`).
- Profile B (e.g. `coder-orchestrator`) includes only its assigned channels in `discord.allowed_channels` and sets `discord.require_mention: false` so it responds without @mention.

`allowed_channels` is a whitelist filter at the adapter level. It is processed in `plugins/platforms/discord/adapter.py` -> `_handle_message` and mapped from YAML -> `DISCORD_ALLOWED_CHANNELS` via the yaml-bridge in `gateway/config.py`.
